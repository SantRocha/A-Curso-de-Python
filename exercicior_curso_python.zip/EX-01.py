# Escreva um código que leia dois números fornecidos pelo usuário e exiba a soma entre eles.
# Solicita que o usuário insira o primeiro número
num1 = float(input("Digite o primeiro número: "))

# Solicita que o usuário insira o segundo número
num2 = float(input("Digite o segundo número: "))

# Calcula a soma dos dois números
soma = num1 + num2

# Exibe o resultado
print(f"A soma entre {num1} e {num2} é {soma}.")
