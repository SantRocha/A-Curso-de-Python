#2 - Crie um programa que leia uma palavra fornecida pelo usuário e informe a quantidade de letras que essa palavra possui.


# Solicita que o usuário insira uma palavra
palavra = input("Digite uma palavra: ")

# Calcula o número de letras da palavra
quantidade_letras = len(palavra)

# Exibe o resultado
print(f"A palavra '{palavra}' tem {quantidade_letras} letras.")


